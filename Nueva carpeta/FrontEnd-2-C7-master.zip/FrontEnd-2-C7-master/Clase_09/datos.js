const gatitos = [
    {
        name: 'Chimu',
        imgUrl: 'img/chimu.png',
        like: false
    },
    {
        name: 'Mei',
        imgUrl: 'img/mei.jpg',
        like: false
    },
    {
        name: 'Gris',
        imgUrl: 'img/gris.jpg',
        like: false
    },
]