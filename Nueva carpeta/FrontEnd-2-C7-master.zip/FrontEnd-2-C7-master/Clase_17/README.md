### Entender de qué se trata una API y reconocer las herramientas que JavaScript nos ofrece de manera nativa para utilizarlas en el desarrollo Front End.


- ¿Qué es una API?
○ REST
○ Leer Documentación
- Fetch (GET)
- try/catch /finally
- APIs públicas