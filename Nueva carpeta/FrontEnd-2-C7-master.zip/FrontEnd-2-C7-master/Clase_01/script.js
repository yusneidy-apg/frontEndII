const apellido = "Cruz";
let nombre = "Jonathan";
let dni = 1234;
let profesor = true;
let cursos = [ 'JavaScript', 'HTML y CSS', 'Python' ];

let alumno = {
    nombre: 'Ale',
    edad: 53,
    curso: 'Front II'
} 


/* console.log("Hola "+ nombre);
console.error("Ocurrio un error");
console.warn("Advertencia");

console.log( typeof(profesor)  )

console.table( alumno) */

if (nombre == 'Jonathan' ){
    console.log('Hola Jona')
}

for (let i = 0; i < cursos.length; i++) {
    console.log( cursos[i]);
}

function sumar(parametro){

    return 
}
