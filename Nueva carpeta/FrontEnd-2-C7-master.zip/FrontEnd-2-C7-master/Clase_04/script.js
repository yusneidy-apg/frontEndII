let titulo = document.querySelector('h1');

function leerNombre(){
    let nombre = document.querySelector('input').value;
    console.log('El nombre es ' + nombre);
}
